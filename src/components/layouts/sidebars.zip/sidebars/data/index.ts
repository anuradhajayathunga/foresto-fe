import * as Icons from '../icons';
import {
  Home,
  UtensilsCrossed,
  ShoppingCart,
  Users,
  BarChart3,
  Settings,
  Package,
  Receipt,
  ChefHat,
  Shield,
  UserCog,
  LayoutDashboard,
  ClipboardList,
  CookingPot,
} from 'lucide-react';

export const NAV_DATA = [
  {
    label: '',
    items: [
      // {
      //   title: "Inventory Management",
      //   icon: Icons.DashboardIcon,
      //   items: [
      //     {
      //       title: "Dashboard",
      //       url: "/dashboard",
      //     },
      //     {
      //       title: "Store",
      //       url: "/store",
      //     },
      //     {
      //       title: "Ingredient",
      //       url: "/ingredient",
      //     },
      //     {
      //       title: "Menu",
      //       url: "/menu",
      //     },
      //     {
      //       title: "Sales",
      //       url: "/sales",
      //     },
      //     {
      //       title: "Orders",
      //       url: "/orders",
      //     },
      //     {
      //       title: "Suppliers",
      //       url: "/suppliers",
      //     },
      //   ],
      // },
      // {
      //   title: "Calendar",
      //   url: "/calendar",
      //   icon: Icons.Calendar,
      //   items: [],
      // },
      {
        title: 'Dashboard',
        url: '/dashboard',
        icon: LayoutDashboard,
        items: [],
      },

      {
        title: 'Sales (POS)',
        url: '/sales',
        icon: Receipt,
        items: [],
      },
      {
        title: 'Menu Items',
        url: '/menu',
        icon: UtensilsCrossed,
        items: [],
      },
      {
        title: 'Inventory',
        url: '/inventory',
        icon: Package,
        items: [],
      },
      {
        title: 'Purchases',
        url: '/purchases',
        icon: ClipboardList,
        items: [],
      },
      {
        title: 'Kitchen',
        url: '/recipes',
        icon: CookingPot,
        items: [],
      },
      // {
      //   title: "Forms",
      //   icon: Icons.Alphabet,
      //   items: [
      //     {
      //       title: "Form Elements",
      //       url: "/forms/form-elements",
      //     },
      //     {
      //       title: "Form Layout",
      //       url: "/forms/form-layout",
      //     },
      //   ],
      // },
      // {
      //   title: "Tables",
      //   url: "/tables",
      //   icon: Icons.Table,
      //   items: [
      //     {
      //       title: "Tables",
      //       url: "/tables",
      //     },
      //   ],
      // },
      // {
      //   title: "Pages",
      //   icon: Icons.Alphabet,
      //   items: [
      //     {
      //       title: "Settings",
      //       url: "/pages/settings",
      //     },
      //   ],
      // },
    ],
  },
  {
    label: '  ',
    items: [
      // {
      //   title: "Charts",
      //   icon: Icons.PieChart,
      //   items: [
      //     {
      //       title: "Basic Chart",
      //       url: "/charts/basic-chart",
      //     },
      //   ],
      // },
      // {
      //   title: "UI Elements",
      //   icon: Icons.FourCircle,
      //   items: [
      //     {
      //       title: "Alerts",
      //       url: "/ui-elements/alerts",
      //     },
      //     {
      //       title: "Buttons",
      //       url: "/ui-elements/buttons",
      //     },
      //   ],
      // },

      {
        title: 'Staff',
        icon: UserCog,
        items: [
          {
            title: 'Suppliers',
            url: '/suppliers',
            icon: Users,
            items: [],
          },
          {
            title: 'Analytics',
            url: '/analytics',
            icon: BarChart3,
            items: [],
          },
        ],
      },
      {
        title: 'Admin Panel',
        url: '/admin',
        icon: Shield,
        items: [],
      },
      {
        title: 'Settings',
        url: '/settings',
        icon: Settings,
        items: [],
      },
    ],
  },
];
